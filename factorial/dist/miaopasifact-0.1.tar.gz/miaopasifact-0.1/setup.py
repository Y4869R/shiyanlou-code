#!/usr/bin/env python3
"""Factorial project"""
from setuptools import find_packages, setup

setup(name = 'miaopasifact',
    version = '0.1',
    description = 'Factorial module.',
    long_description = "A test module for our book.",
    author = "miaopasi",
    author_emial = "429342493@qq.com",
    url = "https://www.xxx.com/Y4869R/shiyanlou-code",
    license = "MIT",
    packages = find_packages()
        )
